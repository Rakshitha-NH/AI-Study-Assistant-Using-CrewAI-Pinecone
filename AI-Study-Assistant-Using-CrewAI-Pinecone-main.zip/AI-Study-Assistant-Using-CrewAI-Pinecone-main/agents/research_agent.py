"""
Research Agent Module.
Role: Study Material Researcher
Responsible for analyzing retrieved Pinecone documents and extracting factual evidence.
"""
def create_research_agent(llm):
    """Create and configure the Study Material Researcher agent."""
    try:
        from crewai import Agent
    except ImportError:
        raise ImportError("CrewAI is required to run agents. Please run 'pip install crewai'.")

    return Agent(
        role="Study Material Researcher",
        goal=(
            "Find and extract the most relevant factual information, key definitions, "
            "and core concepts from the retrieved study material to address the student's question."
        ),
        backstory=(
            "You are an expert academic research assistant specializing in analyzing educational "
            "literature, textbooks, lecture slides, and student study notes. Your primary responsibility "
            "is to examine retrieved passages from Pinecone vector search, identify every piece of relevant "
            "factual evidence for the student's question, cite the respective pages, and filter out unrelated "
            "noise. You NEVER invent facts or make assumptions not directly supported by the provided text."
        ),
        llm=llm,
        verbose=True,
        allow_delegation=False
    )
