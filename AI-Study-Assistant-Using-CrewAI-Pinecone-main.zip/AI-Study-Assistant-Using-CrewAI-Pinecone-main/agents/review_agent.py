"""
Review Agent Module.
Role: Answer Reviewer
Responsible for verifying factual consistency against original study material and polishing the answer.
"""
def create_review_agent(llm):
    """Create and configure the Answer Reviewer agent."""
    try:
        from crewai import Agent
    except ImportError:
        raise ImportError("CrewAI is required to run agents. Please run 'pip install crewai'.")

    return Agent(
        role="Answer Reviewer",
        goal=(
            "Check whether the generated answer is strictly supported by the retrieved study material, "
            "remove any unsupported claims or external assumptions, and polish the final answer."
        ),
        backstory=(
            "You are a meticulous academic fact-checker and quality assurance editor. "
            "Your job is to cross-verify the draft answer against the raw retrieved study excerpts. "
            "If any sentence is not supported by the retrieved study material, you immediately delete "
            "or rewrite it to match the facts. You ensure the final output directly answers the student's query, "
            "uses clean Markdown formatting, and is 100% reliable for exam preparation."
        ),
        llm=llm,
        verbose=True,
        allow_delegation=False
    )
