"""
Unit tests for RAG pipeline components: PDFProcessor, TextChunker, EmbeddingManager.
"""
import unittest
from rag.pdf_processor import PDFProcessor
from rag.chunker import TextChunker


class TestRAGPipeline(unittest.TestCase):
    """Test suite for PDF processing and text chunking."""

    def test_clean_text(self):
        """Test whitespace and unprintable character cleaning."""
        raw_text = "This  is   a\r\ntest   string\n\n\n\nwith extra  spaces."
        cleaned = PDFProcessor.clean_text(raw_text)
        self.assertNotIn("\r", cleaned)
        self.assertNotIn("   ", cleaned)
        self.assertTrue("This is a" in cleaned)

    def test_chunker_basic_split(self):
        """Test splitting text into chunks respecting chunk_size."""
        sample_text = (
            "Machine learning is a subfield of artificial intelligence. "
            "It focuses on the development of algorithms that allow computers to learn from data. "
            "Supervised learning is where the model learns from labeled training data. "
            "Unsupervised learning deals with unlabeled data and discovers hidden patterns. "
            "Reinforcement learning trains agents by rewarding desired behaviors. "
        ) * 5  # Make long enough to split

        chunks = TextChunker.split_text_into_chunks(sample_text, chunk_size=300, chunk_overlap=50)
        self.assertGreater(len(chunks), 1)
        for chunk in chunks:
            # Allow minor leeway for natural sentence boundary
            self.assertLessEqual(len(chunk), 400)
            self.assertGreater(len(chunk), 20)

    def test_chunk_document_metadata(self):
        """Test that chunks retain page number and document metadata."""
        pages_data = [
            {"page": 1, "text": "Chapter 1: Foundations of Computer Networks. TCP and UDP are transport layer protocols."},
            {"page": 2, "text": "Chapter 2: Routing Algorithms. Dijkstra algorithm is used for shortest path calculation."}
        ]

        chunks = TextChunker.chunk_document(
            pages_data=pages_data,
            filename="Networks_Unit_1.pdf",
            doc_id="doc_net_101",
            chunk_size=500,
            chunk_overlap=50
        )

        self.assertEqual(len(chunks), 2)
        self.assertEqual(chunks[0]["page"], 1)
        self.assertEqual(chunks[0]["filename"], "Networks_Unit_1.pdf")
        self.assertEqual(chunks[0]["doc_id"], "doc_net_101")
        self.assertTrue("TCP and UDP" in chunks[0]["text"])

        self.assertEqual(chunks[1]["page"], 2)
        self.assertEqual(chunks[1]["filename"], "Networks_Unit_1.pdf")
        self.assertTrue("Dijkstra" in chunks[1]["text"])


if __name__ == "__main__":
    unittest.main()
