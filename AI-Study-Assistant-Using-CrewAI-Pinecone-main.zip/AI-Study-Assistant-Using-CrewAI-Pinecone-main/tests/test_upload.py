"""
Unit tests for upload validation and error handling.
"""
import io
import unittest
from app import create_app


class TestUploadEndpoints(unittest.TestCase):
    """Test suite for /api/upload endpoint."""

    def setUp(self):
        self.app = create_app()
        self.app.config["TESTING"] = True
        self.client = self.app.test_client()

    def test_upload_no_file(self):
        """Test upload endpoint when no file parameter is sent."""
        res = self.client.post("/api/upload", data={})
        self.assertEqual(res.status_code, 400)
        data = res.get_json()
        self.assertFalse(data["success"])
        self.assertIn("No file", data["error"])

    def test_upload_invalid_extension(self):
        """Test upload endpoint with a non-PDF file (e.g. .txt or .exe)."""
        data = {
            "file": (io.BytesIO(b"dummy text content"), "notes.txt")
        }
        res = self.client.post("/api/upload", data=data, content_type="multipart/form-data")
        self.assertEqual(res.status_code, 400)
        json_data = res.get_json()
        self.assertFalse(json_data["success"])
        self.assertIn("Only PDF", json_data["error"])

    def test_upload_empty_filename(self):
        """Test upload endpoint with empty filename."""
        data = {
            "file": (io.BytesIO(b""), "")
        }
        res = self.client.post("/api/upload", data=data, content_type="multipart/form-data")
        self.assertEqual(res.status_code, 400)


if __name__ == "__main__":
    unittest.main()
