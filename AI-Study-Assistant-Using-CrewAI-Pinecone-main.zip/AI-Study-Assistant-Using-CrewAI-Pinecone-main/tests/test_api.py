"""
Integration tests for Flask API routes: /api/health, /api/stats, /api/documents, /api/ask.
"""
import unittest
from app import create_app
from data.store import add_document, get_all_documents, delete_document


class TestAPIRoutes(unittest.TestCase):
    """Test suite for application API routes."""

    def setUp(self):
        self.app = create_app()
        self.app.config["TESTING"] = True
        self.client = self.app.test_client()

    def test_health_check(self):
        """Test GET /api/health endpoint."""
        res = self.client.get("/api/health")
        self.assertEqual(res.status_code, 200)
        data = res.get_json()
        self.assertEqual(data["status"], "healthy")
        self.assertIn("system", data)
        self.assertIn("embedding_dim", data["system"])
        self.assertEqual(data["system"]["embedding_dim"], 384)

    def test_stats_endpoint(self):
        """Test GET /api/stats endpoint."""
        res = self.client.get("/api/stats")
        self.assertEqual(res.status_code, 200)
        data = res.get_json()
        self.assertTrue(data["success"])
        self.assertIn("total_documents", data["stats"])
        self.assertIn("questions_asked", data["stats"])

    def test_documents_crud(self):
        """Test adding, listing, and deleting documents."""
        test_doc = {
            "doc_id": "test_doc_999",
            "filename": "Calculus_Notes.pdf",
            "pages": 10,
            "chunks": 35,
            "file_size": "1.2 MB",
            "status": "Indexed"
        }
        add_document(test_doc)

        res = self.client.get("/api/documents")
        self.assertEqual(res.status_code, 200)
        data = res.get_json()
        self.assertTrue(data["success"])
        found = any(d["doc_id"] == "test_doc_999" for d in data["documents"])
        self.assertTrue(found)

        # Clean up
        delete_document("test_doc_999")

    def test_ask_empty_question(self):
        """Test POST /api/ask with an empty question."""
        res = self.client.post(
            "/api/ask",
            json={"question": "   "},
            headers={"Content-Type": "application/json"}
        )
        self.assertEqual(res.status_code, 400)
        data = res.get_json()
        self.assertFalse(data["success"])
        self.assertIn("non-empty question", data["error"])


if __name__ == "__main__":
    unittest.main()
