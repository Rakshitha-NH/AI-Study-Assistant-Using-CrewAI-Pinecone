"""
AI Study Assistant Using CrewAI & Pinecone
Main Flask Application Entry Point.
"""
import os
from flask import Flask, render_template, jsonify
from flask_cors import CORS
from config.config import Config
from routes.upload_routes import upload_bp
from routes.question_routes import question_bp
from routes.document_routes import document_bp


def create_app():
    """Application factory for AI Study Assistant."""
    app = Flask(__name__)
    app.config.from_object(Config)

    # Enable Cross-Origin Resource Sharing
    CORS(app)

    # Register API Blueprints
    app.register_blueprint(upload_bp)
    app.register_blueprint(question_bp)
    app.register_blueprint(document_bp)

    # Global Template Context Processor
    @app.context_processor
    def inject_global_vars():
        return {
            "app_name": Config.APP_NAME,
            "app_version": Config.APP_VERSION,
            "groq_configured": Config.is_groq_configured(),
            "pinecone_configured": Config.is_pinecone_configured(),
            "groq_model": Config.GROQ_MODEL,
            "pinecone_index": Config.PINECONE_INDEX_NAME
        }

    # ==========================================================================
    # Web UI Routes
    # ==========================================================================
    @app.route("/")
    def index():
        """Dashboard view."""
        return render_template("index.html")

    @app.route("/upload")
    def upload_view():
        """Upload study material view."""
        return render_template("upload.html")

    @app.route("/chat")
    def chat_view():
        """Ask question / chat view."""
        return render_template("chat.html")

    @app.route("/documents")
    def documents_view():
        """Document library view."""
        return render_template("documents.html")

    @app.route("/how-it-works")
    def how_it_works_view():
        """Architecture and agent flow explanation view."""
        return render_template("how-it-works.html")

    # ==========================================================================
    # Error Handlers
    # ==========================================================================
    @app.errorhandler(404)
    def not_found_error(error):
        return render_template("index.html"), 404

    @app.errorhandler(413)
    def file_too_large_error(error):
        return jsonify({
            "success": False,
            "error": "File size exceeds the 32MB limit. Please upload a smaller PDF."
        }), 413

    @app.errorhandler(500)
    def internal_server_error(error):
        return jsonify({
            "success": False,
            "error": "An unexpected internal server error occurred."
        }), 500

    return app


app = create_app()

if __name__ == "__main__":
    print("=" * 60)
    print("  🚀 AI Study Assistant Using CrewAI & Pinecone")
    print(f"  📍 Server running at: http://127.0.0.1:{Config.FLASK_PORT}")
    print(f"  🔑 Groq Configured: {Config.is_groq_configured()}")
    print(f"  🌲 Pinecone Configured: {Config.is_pinecone_configured()}")
    print("=" * 60)
    app.run(host="0.0.0.0", port=Config.FLASK_PORT, debug=False, use_reloader=False)
