"""
Local JSON-based document store and statistics manager.
Provides persistence for document metadata and application metrics.
"""
import os
import json
from datetime import datetime
from threading import Lock
from config.config import Config

_lock = Lock()


def _load_store() -> dict:
    """Load JSON store from disk or return default structure."""
    if not os.path.exists(Config.DOC_STORE_PATH):
        return {
            "documents": [],
            "stats": {
                "questions_asked": 0,
                "total_chunks_indexed": 0
            }
        }
    try:
        with open(Config.DOC_STORE_PATH, "r", encoding="utf-8") as f:
            data = json.load(f)
            if "documents" not in data:
                data["documents"] = []
            if "stats" not in data:
                data["stats"] = {"questions_asked": 0, "total_chunks_indexed": 0}
            return data
    except Exception:
        return {
            "documents": [],
            "stats": {
                "questions_asked": 0,
                "total_chunks_indexed": 0
            }
        }


def _save_store(data: dict) -> None:
    """Save JSON store safely to disk."""
    os.makedirs(os.path.dirname(Config.DOC_STORE_PATH), exist_ok=True)
    with open(Config.DOC_STORE_PATH, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)


def get_all_documents() -> list:
    """Retrieve list of all indexed documents."""
    with _lock:
        data = _load_store()
        return data.get("documents", [])


def get_document_by_id(doc_id: str) -> dict | None:
    """Retrieve single document metadata by ID."""
    with _lock:
        data = _load_store()
        for doc in data.get("documents", []):
            if doc.get("doc_id") == doc_id:
                return doc
        return None


def add_document(doc_metadata: dict) -> dict:
    """Add or update document metadata in store."""
    with _lock:
        data = _load_store()
        # Remove if already exists with same doc_id
        docs = [d for d in data.get("documents", []) if d.get("doc_id") != doc_metadata.get("doc_id")]
        
        if "uploaded_at" not in doc_metadata:
            doc_metadata["uploaded_at"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        if "status" not in doc_metadata:
            doc_metadata["status"] = "Indexed"
            
        docs.insert(0, doc_metadata)
        data["documents"] = docs
        
        # Update total chunks indexed
        total_chunks = sum(d.get("chunks", 0) for d in docs)
        data["stats"]["total_chunks_indexed"] = total_chunks
        
        _save_store(data)
        return doc_metadata


def delete_document(doc_id: str) -> bool:
    """Remove document from store by doc_id."""
    with _lock:
        data = _load_store()
        initial_len = len(data.get("documents", []))
        data["documents"] = [d for d in data.get("documents", []) if d.get("doc_id") != doc_id]
        
        if len(data["documents"]) < initial_len:
            total_chunks = sum(d.get("chunks", 0) for d in data["documents"])
            data["stats"]["total_chunks_indexed"] = total_chunks
            _save_store(data)
            return True
        return False


def increment_questions_count() -> int:
    """Increment the total count of questions asked."""
    with _lock:
        data = _load_store()
        current = data.get("stats", {}).get("questions_asked", 0) + 1
        data["stats"]["questions_asked"] = current
        _save_store(data)
        return current


def get_stats() -> dict:
    """Get aggregated statistics for dashboard."""
    with _lock:
        data = _load_store()
        docs = data.get("documents", [])
        total_docs = len(docs)
        indexed_docs = len([d for d in docs if d.get("status") == "Indexed"])
        total_chunks = sum(d.get("chunks", 0) for d in docs)
        total_pages = sum(d.get("pages", 0) for d in docs)
        questions_asked = data.get("stats", {}).get("questions_asked", 0)

        return {
            "total_documents": total_docs,
            "indexed_documents": indexed_docs,
            "questions_asked": questions_asked,
            "vector_records": total_chunks,
            "total_pages": total_pages
        }
