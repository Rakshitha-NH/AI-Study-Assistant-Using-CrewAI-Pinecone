"""Data persistence package."""
from data.store import (
    get_all_documents,
    get_document_by_id,
    add_document,
    delete_document,
    increment_questions_count,
    get_stats
)

__all__ = [
    "get_all_documents",
    "get_document_by_id",
    "add_document",
    "delete_document",
    "increment_questions_count",
    "get_stats"
]
