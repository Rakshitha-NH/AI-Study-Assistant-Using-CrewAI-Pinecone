"""
Upload Routes.
Handles PDF file uploads, page extraction, chunking, and Pinecone vector indexing.
"""
import os
import time
import uuid
from flask import Blueprint, request, jsonify
from werkzeug.utils import secure_filename
from config.config import Config
from rag.pdf_processor import PDFProcessor
from rag.chunker import TextChunker
from rag.pinecone_manager import PineconeManager
from data.store import add_document

upload_bp = Blueprint("upload_bp", __name__)


def allowed_file(filename: str) -> bool:
    """Check if the uploaded file has an allowed extension."""
    return "." in filename and filename.rsplit(".", 1)[1].lower() in Config.ALLOWED_EXTENSIONS


@upload_bp.route("/api/upload", methods=["POST"])
def upload_file():
    """
    POST /api/upload
    Accepts multipart/form-data with 'file'.
    Extracts text, creates chunks, generates embeddings, and indexes into Pinecone.
    """
    if "file" not in request.files:
        return jsonify({
            "success": False,
            "error": "No file part in the request."
        }), 400

    file = request.files["file"]

    if file.filename == "":
        return jsonify({
            "success": False,
            "error": "No file was selected for upload."
        }), 400

    if not allowed_file(file.filename):
        return jsonify({
            "success": False,
            "error": "Invalid file type. Only PDF (.pdf) documents are supported."
        }), 400

    # Ensure Pinecone is configured before proceeding
    if not Config.is_pinecone_configured():
        return jsonify({
            "success": False,
            "error": "Pinecone API key is not configured. Please add PINECONE_API_KEY to your .env file."
        }), 500

    try:
        # Save file securely
        original_filename = secure_filename(file.filename) or "document.pdf"
        doc_id = f"doc_{int(time.time())}_{uuid.uuid4().hex[:6]}"
        saved_filename = f"{doc_id}_{original_filename}"
        saved_path = os.path.join(Config.UPLOAD_FOLDER, saved_filename)
        file.save(saved_path)

        # 1. Extract text by pages
        pages_data = PDFProcessor.extract_text_by_pages(saved_path)
        meta = PDFProcessor.get_pdf_metadata(saved_path)
        num_pages = len(pages_data)

        # 2. Chunk text
        chunks = TextChunker.chunk_document(
            pages_data=pages_data,
            filename=original_filename,
            doc_id=doc_id
        )

        if not chunks:
            # Clean up file
            if os.path.exists(saved_path):
                os.remove(saved_path)
            return jsonify({
                "success": False,
                "error": "The uploaded PDF did not contain sufficient readable text to index."
            }), 400

        # 3. Upsert to Pinecone
        indexed_count = PineconeManager.upsert_chunks(chunks)

        # 4. Save metadata to local store
        doc_record = {
            "doc_id": doc_id,
            "filename": original_filename,
            "saved_filename": saved_filename,
            "pages": num_pages,
            "chunks": len(chunks),
            "file_size": meta.get("file_size", "0 KB"),
            "status": "Indexed"
        }
        add_document(doc_record)

        return jsonify({
            "success": True,
            "message": "Document uploaded and indexed successfully.",
            "doc_id": doc_id,
            "filename": original_filename,
            "pages": num_pages,
            "chunks": len(chunks),
            "indexed_vectors": indexed_count,
            "file_size": meta.get("file_size", "0 KB")
        }), 200

    except ValueError as ve:
        return jsonify({
            "success": False,
            "error": str(ve)
        }), 400
    except Exception as e:
        return jsonify({
            "success": False,
            "error": f"Failed to process and index document: {str(e)}"
        }), 500
