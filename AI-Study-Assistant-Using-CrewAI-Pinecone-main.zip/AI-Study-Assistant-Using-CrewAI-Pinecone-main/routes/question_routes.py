"""
Question & Answering Routes.
Handles user questions, semantic vector retrieval from Pinecone, and CrewAI multi-agent reasoning.
"""
from flask import Blueprint, request, jsonify
from config.config import Config
from rag.pinecone_manager import PineconeManager
from crew.crew_manager import CrewManager
from data.store import increment_questions_count, get_all_documents

question_bp = Blueprint("question_bp", __name__)


@question_bp.route("/api/ask", methods=["POST"])
def ask_question():
    """
    POST /api/ask
    Request JSON: { "question": "What is supervised learning?" }
    Response JSON: {
        "success": true,
        "question": "...",
        "answer": "...",
        "sources": [{"filename": "...", "page": 5}]
    }
    """
    data = request.get_json(silent=True) or {}
    question = data.get("question", "").strip()

    if not question:
        return jsonify({
            "success": False,
            "error": "Please provide a valid, non-empty question."
        }), 400

    # Validate API key configurations
    if not Config.is_groq_configured():
        return jsonify({
            "success": False,
            "error": "Groq API key is not configured. Please add GROQ_API_KEY to your .env file."
        }), 500

    if not Config.is_pinecone_configured():
        return jsonify({
            "success": False,
            "error": "Pinecone API key is not configured. Please add PINECONE_API_KEY to your .env file."
        }), 500

    # Check if any documents have been uploaded
    docs = get_all_documents()
    if not docs:
        return jsonify({
            "success": True,
            "question": question,
            "answer": (
                "No study materials have been uploaded yet. "
                "Please go to the Upload page and upload your course PDFs first!"
            ),
            "sources": [],
            "chunks_used": 0
        }), 200

    try:
        # 1. Semantic Search in Pinecone
        retrieved_chunks = PineconeManager.search(question, top_k=Config.TOP_K)

        if not retrieved_chunks:
            return jsonify({
                "success": True,
                "question": question,
                "answer": "I could not find enough information in the uploaded study material to answer this question.",
                "sources": [],
                "chunks_used": 0
            }), 200

        # 2. Run CrewAI Multi-Agent Workflow
        result = CrewManager.run_study_assistant(question, retrieved_chunks)

        # 3. Increment statistics counter
        increment_questions_count()

        return jsonify({
            "success": True,
            "question": question,
            "answer": result.get("answer", ""),
            "sources": result.get("sources", []),
            "chunks_used": result.get("chunks_used", len(retrieved_chunks))
        }), 200

    except Exception as e:
        return jsonify({
            "success": False,
            "error": f"Error during AI agent processing: {str(e)}"
        }), 500
