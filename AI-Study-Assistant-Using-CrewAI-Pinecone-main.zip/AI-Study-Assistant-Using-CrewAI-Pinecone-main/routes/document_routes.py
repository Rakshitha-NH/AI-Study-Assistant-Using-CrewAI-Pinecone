"""
Document & Statistics Management Routes.
Provides endpoints for document listing, deletion, dashboard metrics, and health checks.
"""
import os
from flask import Blueprint, jsonify
from config.config import Config
from data.store import get_all_documents, delete_document, get_stats
from rag.pinecone_manager import PineconeManager

document_bp = Blueprint("document_bp", __name__)


@document_bp.route("/api/documents", methods=["GET"])
def list_documents():
    """GET /api/documents - Returns all indexed documents."""
    docs = get_all_documents()
    return jsonify({
        "success": True,
        "count": len(docs),
        "documents": docs
    }), 200


@document_bp.route("/api/documents/<doc_id>", methods=["DELETE"])
def remove_document(doc_id: str):
    """DELETE /api/documents/<doc_id> - Delete a document and its vectors."""
    try:
        # Delete vectors from Pinecone if configured
        if Config.is_pinecone_configured():
            PineconeManager.delete_document_vectors(doc_id)

        # Remove from local data store
        deleted = delete_document(doc_id)
        if deleted:
            return jsonify({
                "success": True,
                "message": f"Document {doc_id} deleted successfully."
            }), 200
        else:
            return jsonify({
                "success": False,
                "error": "Document not found."
            }), 404
    except Exception as e:
        return jsonify({
            "success": False,
            "error": f"Failed to delete document: {str(e)}"
        }), 500


@document_bp.route("/api/stats", methods=["GET"])
def fetch_stats():
    """GET /api/stats - Aggregated metrics for dashboard cards."""
    stats = get_stats()
    
    # Check Pinecone vector count if possible
    pinecone_stats = PineconeManager.get_index_stats()
    if pinecone_stats.get("status") == "Connected" and pinecone_stats.get("vector_count", 0) > 0:
        stats["vector_records"] = pinecone_stats["vector_count"]

    return jsonify({
        "success": True,
        "stats": stats
    }), 200


@document_bp.route("/api/health", methods=["GET"])
def health_check():
    """GET /api/health - System and integration health status."""
    sys_status = Config.get_system_status()
    pinecone_info = PineconeManager.get_index_stats()

    return jsonify({
        "status": "healthy",
        "system": sys_status,
        "pinecone": pinecone_info
    }), 200
