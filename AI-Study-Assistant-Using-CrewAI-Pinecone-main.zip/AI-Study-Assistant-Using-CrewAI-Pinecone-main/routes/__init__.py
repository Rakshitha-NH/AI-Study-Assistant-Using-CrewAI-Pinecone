"""Routes package for AI Study Assistant."""
from routes.upload_routes import upload_bp
from routes.question_routes import question_bp
from routes.document_routes import document_bp

__all__ = ["upload_bp", "question_bp", "document_bp"]
