/**
 * Chat Page JavaScript.
 * Powers multi-turn interactive Q&A, markdown formatting, suggestion chips, and source citations.
 */
document.addEventListener("DOMContentLoaded", () => {
    const chatFeed = document.getElementById("chatFeed");
    const chatForm = document.getElementById("chatForm");
    const chatInput = document.getElementById("chatInput");
    const sendBtn = document.getElementById("sendBtn");
    const reasoningPanel = document.getElementById("chatAgentReasoning");
    const reasoningAgentName = document.getElementById("reasoningAgentName");
    const reasoningStepDetail = document.getElementById("reasoningStepDetail");
    const sessionList = document.getElementById("sessionQuestionsList");
    const clearBtn = document.getElementById("clearChatBtn");

    let sessionQuestions = [];

    // Enter key submits form (Shift+Enter for newline)
    chatInput.addEventListener("keydown", (e) => {
        if (e.key === "Enter" && !e.shiftKey) {
            e.preventDefault();
            chatForm.dispatchEvent(new Event("submit"));
        }
    });

    // Preset suggestion chips
    document.querySelectorAll(".chip-btn").forEach(btn => {
        btn.addEventListener("click", () => {
            chatInput.value = btn.getAttribute("data-query");
            chatForm.dispatchEvent(new Event("submit"));
        });
    });

    // Clear Chat
    clearBtn?.addEventListener("click", () => {
        chatFeed.innerHTML = `
            <div class="chat-bubble assistant-bubble">
                <div class="bubble-header">
                    <i class="fa-solid fa-graduation-cap me-1 text-primary"></i> Study Assistant
                </div>
                <div class="bubble-content">
                    Chat history cleared. Ask me any question from your uploaded study materials!
                </div>
            </div>
        `;
    });

    chatForm.addEventListener("submit", async (e) => {
        e.preventDefault();
        const question = chatInput.value.trim();
        if (!question) return;

        // 1. Append User Message
        appendUserMessage(question);
        chatInput.value = "";
        chatInput.focus();

        // Track in session questions
        addSessionQuestion(question);

        // 2. Start Agent Reasoning Indicator
        sendBtn.disabled = true;
        reasoningPanel.classList.remove("d-none");
        scrollToBottom();

        const agentSteps = [
            { agent: "Pinecone Vector Store", detail: "Querying dense embeddings (top_k=5)..." },
            { agent: "1. Study Material Researcher", detail: "Analyzing passages & extracting hard factual evidence..." },
            { agent: "2. Study Material Analyst", detail: "Synthesizing clear student explanation & definitions..." },
            { agent: "3. Answer Reviewer", detail: "Fact-checking claims against source text & formatting final response..." }
        ];

        let stepIndex = 0;
        const intervalId = setInterval(() => {
            stepIndex = (stepIndex + 1) % agentSteps.length;
            reasoningAgentName.textContent = agentSteps[stepIndex].agent;
            reasoningStepDetail.textContent = agentSteps[stepIndex].detail;
        }, 1500);

        try {
            const res = await fetch("/api/ask", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ question })
            });
            const data = await res.json();
            clearInterval(intervalId);

            if (data.success) {
                appendAssistantMessage(data.answer, data.sources);
            } else {
                appendAssistantMessage(`⚠️ **Error:** ${data.error || "Unable to retrieve answer."}`);
            }

        } catch (err) {
            clearInterval(intervalId);
            appendAssistantMessage(`⚠️ **Network Error:** ${err.message}`);
        } finally {
            sendBtn.disabled = false;
            reasoningPanel.classList.add("d-none");
            scrollToBottom();
        }
    });

    function appendUserMessage(text) {
        const bubble = document.createElement("div");
        bubble.className = "chat-bubble user-bubble";
        bubble.innerHTML = `
            <div class="bubble-header text-white-50">
                <i class="fa-solid fa-user me-1"></i> You
            </div>
            <div class="bubble-content">
                ${escapeHtml(text).replace(/\n/g, "<br>")}
            </div>
        `;
        chatFeed.appendChild(bubble);
        scrollToBottom();
    }

    function appendAssistantMessage(rawMarkdown, sources = []) {
        const bubble = document.createElement("div");
        bubble.className = "chat-bubble assistant-bubble";

        const parsedContent = typeof marked !== "undefined" ? marked.parse(rawMarkdown) : rawMarkdown;
        let sourcesHtml = "";

        if (sources && sources.length > 0) {
            const pills = sources.map(s => `
                <span class="citation-pill">
                    <i class="fa-solid fa-file-pdf"></i>
                    ${s.filename} · Page ${s.page}
                </span>
            `).join("");

            sourcesHtml = `
                <div class="mt-3 pt-2 border-top">
                    <div class="small text-muted mb-1"><i class="fa-solid fa-book-bookmark me-1"></i> Verified Sources:</div>
                    <div class="d-flex flex-wrap gap-2">${pills}</div>
                </div>
            `;
        }

        bubble.innerHTML = `
            <div class="bubble-header d-flex justify-content-between align-items-center">
                <span><i class="fa-solid fa-graduation-cap me-1 text-primary"></i> Study Assistant (Verified by Review Agent)</span>
            </div>
            <div class="bubble-content">
                ${parsedContent}
                ${sourcesHtml}
            </div>
        `;
        chatFeed.appendChild(bubble);
        scrollToBottom();
    }

    function addSessionQuestion(q) {
        sessionQuestions.unshift(q);
        if (sessionQuestions.length > 8) sessionQuestions.pop();

        sessionList.innerHTML = sessionQuestions.map(item => `
            <div class="session-q-item p-2 mb-1 rounded bg-light small text-truncate" style="cursor: pointer;" title="${escapeHtml(item)}">
                <i class="fa-solid fa-question-circle text-primary me-1"></i> ${escapeHtml(item)}
            </div>
        `).join("");

        // Clicking a session question loads it back into chat input
        sessionList.querySelectorAll(".session-q-item").forEach((el, idx) => {
            el.addEventListener("click", () => {
                chatInput.value = sessionQuestions[idx];
                chatInput.focus();
            });
        });
    }

    function scrollToBottom() {
        chatFeed.scrollTop = chatFeed.scrollHeight;
    }

    function escapeHtml(str) {
        const div = document.createElement("div");
        div.textContent = str;
        return div.innerHTML;
    }
});
