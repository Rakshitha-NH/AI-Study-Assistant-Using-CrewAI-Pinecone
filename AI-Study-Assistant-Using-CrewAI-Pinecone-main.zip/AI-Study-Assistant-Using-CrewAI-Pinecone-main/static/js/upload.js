/**
 * Upload Page JavaScript.
 * Manages PDF drag-and-drop, client-side validation, and multi-stage pipeline animation.
 */
document.addEventListener("DOMContentLoaded", () => {
    let selectedFile = null;

    const dropzone = document.getElementById("uploadDropzone");
    const fileInput = document.getElementById("pdfFileInput");
    const fileCard = document.getElementById("fileDetailsCard");
    const fileNameEl = document.getElementById("selectedFileName");
    const fileSizeEl = document.getElementById("selectedFileSize");
    const removeBtn = document.getElementById("removeFileBtn");
    const uploadBtn = document.getElementById("startUploadBtn");
    const progressCard = document.getElementById("pipelineProgressCard");
    const successCard = document.getElementById("uploadSuccessCard");
    const uploadAnotherBtn = document.getElementById("uploadAnotherBtn");

    // Drag & Drop
    dropzone.addEventListener("dragover", (e) => {
        e.preventDefault();
        dropzone.classList.add("dragover");
    });

    dropzone.addEventListener("dragleave", () => {
        dropzone.classList.remove("dragover");
    });

    dropzone.addEventListener("drop", (e) => {
        e.preventDefault();
        dropzone.classList.remove("dragover");
        if (e.dataTransfer.files.length > 0) {
            selectFile(e.dataTransfer.files[0]);
        }
    });

    fileInput.addEventListener("change", (e) => {
        if (e.target.files.length > 0) {
            selectFile(e.target.files[0]);
        }
    });

    function selectFile(file) {
        if (!file.name.toLowerCase().endsWith(".pdf")) {
            window.showToast("Only PDF documents (.pdf) are allowed.", "danger");
            return;
        }

        selectedFile = file;
        fileNameEl.textContent = file.name;
        const sizeFormatted = file.size >= 1024*1024 
            ? `${(file.size / (1024 * 1024)).toFixed(2)} MB`
            : `${(file.size / 1024).toFixed(1)} KB`;
        fileSizeEl.textContent = sizeFormatted;

        fileCard.classList.remove("d-none");
        dropzone.classList.add("d-none");
        successCard.classList.add("d-none");
        progressCard.classList.add("d-none");
    }

    removeBtn.addEventListener("click", () => {
        resetUpload();
    });

    uploadAnotherBtn.addEventListener("click", () => {
        resetUpload();
    });

    function resetUpload() {
        selectedFile = null;
        fileInput.value = "";
        fileCard.classList.add("d-none");
        dropzone.classList.remove("d-none");
        progressCard.classList.add("d-none");
        successCard.classList.add("d-none");
        resetSteps();
    }

    function resetSteps() {
        ["stepUpload", "stepExtract", "stepChunk", "stepEmbed", "stepIndex"].forEach(id => {
            const el = document.getElementById(id);
            if (el) {
                el.className = "step-item";
            }
        });
    }

    function activateStep(stepId) {
        const el = document.getElementById(stepId);
        if (el) el.className = "step-item active";
    }

    function completeStep(stepId) {
        const el = document.getElementById(stepId);
        if (el) el.className = "step-item completed";
    }

    uploadBtn.addEventListener("click", async () => {
        if (!selectedFile) return;

        uploadBtn.disabled = true;
        progressCard.classList.remove("d-none");
        resetSteps();

        // 1. Uploading step
        activateStep("stepUpload");

        const formData = new FormData();
        formData.append("file", selectedFile);

        // Animated stage transitions while backend processes
        const t1 = setTimeout(() => {
            completeStep("stepUpload");
            activateStep("stepExtract");
        }, 500);

        const t2 = setTimeout(() => {
            completeStep("stepExtract");
            activateStep("stepChunk");
        }, 1200);

        const t3 = setTimeout(() => {
            completeStep("stepChunk");
            activateStep("stepEmbed");
        }, 2200);

        const t4 = setTimeout(() => {
            completeStep("stepEmbed");
            activateStep("stepIndex");
        }, 3400);

        try {
            const res = await fetch("/api/upload", {
                method: "POST",
                body: formData
            });
            const data = await res.json();

            clearTimeout(t1);
            clearTimeout(t2);
            clearTimeout(t3);
            clearTimeout(t4);

            if (data.success) {
                // Complete all steps
                ["stepUpload", "stepExtract", "stepChunk", "stepEmbed", "stepIndex"].forEach(completeStep);

                setTimeout(() => {
                    progressCard.classList.add("d-none");
                    fileCard.classList.add("d-none");
                    successCard.classList.remove("d-none");

                    document.getElementById("successPages").textContent = data.pages || 1;
                    document.getElementById("successChunks").textContent = data.chunks || 0;
                    document.getElementById("successVectors").textContent = data.indexed_vectors || data.chunks || 0;
                    document.getElementById("successMessageDetails").textContent = 
                        `"${data.filename}" (${data.file_size}) was chunked into ${data.chunks} passages and stored in Pinecone.`;

                    window.showToast("Document indexed successfully!", "success");
                }, 600);

            } else {
                resetSteps();
                progressCard.classList.add("d-none");
                window.showToast(data.error || "Upload failed", "danger");
            }
        } catch (err) {
            clearTimeout(t1);
            clearTimeout(t2);
            clearTimeout(t3);
            clearTimeout(t4);
            resetSteps();
            progressCard.classList.add("d-none");
            window.showToast(`Upload failed: ${err.message}`, "danger");
        } finally {
            uploadBtn.disabled = false;
        }
    });
});
