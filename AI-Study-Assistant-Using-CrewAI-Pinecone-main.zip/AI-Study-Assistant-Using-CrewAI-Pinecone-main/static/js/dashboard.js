/**
 * Dashboard JavaScript.
 * Loads dynamic statistics and powers the quick ask & quick dropzone forms.
 */
document.addEventListener("DOMContentLoaded", () => {
    loadDashboardStats();
    setupQuickAskForm();
    setupMiniDropzone();
});

async function loadDashboardStats() {
    try {
        const res = await fetch("/api/stats");
        const data = await res.json();
        if (data.success && data.stats) {
            document.getElementById("statTotalDocs").textContent = data.stats.total_documents ?? 0;
            document.getElementById("statIndexedDocs").textContent = data.stats.indexed_documents ?? 0;
            document.getElementById("statQuestionsAsked").textContent = data.stats.questions_asked ?? 0;
            document.getElementById("statVectorRecords").textContent = data.stats.vector_records ?? 0;
        }
    } catch (e) {
        console.error("Failed to load dashboard stats", e);
    }
}

function setupQuickAskForm() {
    const form = document.getElementById("quickAskForm");
    const input = document.getElementById("quickQuestionInput");
    const btn = document.getElementById("quickAskBtn");
    const progress = document.getElementById("quickAgentProgress");
    const resultCard = document.getElementById("quickResultCard");
    const answerText = document.getElementById("quickAnswerText");
    const sourcesList = document.getElementById("quickSourcesList");
    const stepLabel = document.getElementById("quickAgentStep");

    if (!form) return;

    form.addEventListener("submit", async (e) => {
        e.preventDefault();
        const question = input.value.trim();
        if (!question) return;

        // UI Loading state
        btn.disabled = true;
        progress.classList.remove("d-none");
        resultCard.classList.add("d-none");

        // Simulate multi-agent steps in UI
        let stepIdx = 0;
        const steps = [
            "Pinecone: Querying dense 384-dim semantic vectors...",
            "Research Agent: Analyzing passages & extracting evidence...",
            "Analysis Agent: Synthesizing student explanation...",
            "Review Agent: Verifying factual claims & formatting answer..."
        ];
        const stepInterval = setInterval(() => {
            stepIdx = (stepIdx + 1) % steps.length;
            stepLabel.textContent = steps[stepIdx];
        }, 1400);

        try {
            const res = await fetch("/api/ask", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ question })
            });
            const data = await res.json();
            clearInterval(stepInterval);

            if (data.success) {
                // Render markdown answer
                answerText.innerHTML = typeof marked !== "undefined" ? marked.parse(data.answer) : data.answer;
                
                // Render citations
                if (data.sources && data.sources.length > 0) {
                    sourcesList.innerHTML = data.sources.map(s => `
                        <span class="citation-pill">
                            <i class="fa-solid fa-file-pdf"></i>
                            ${s.filename} (Page ${s.page})
                        </span>
                    `).join("");
                    document.getElementById("quickSourcesSection").classList.remove("d-none");
                } else {
                    document.getElementById("quickSourcesSection").classList.add("d-none");
                }

                resultCard.classList.remove("d-none");
                loadDashboardStats(); // Refresh questions counter
            } else {
                window.showToast(data.error || "Failed to get an answer.", "danger");
            }
        } catch (err) {
            clearInterval(stepInterval);
            window.showToast(`Error: ${err.message}`, "danger");
        } finally {
            btn.disabled = false;
            progress.classList.add("d-none");
        }
    });
}

function setupMiniDropzone() {
    const dropzone = document.getElementById("miniDropzone");
    const fileInput = document.getElementById("miniFileInput");
    const statusBox = document.getElementById("miniUploadStatus");
    const statusText = document.getElementById("miniUploadText");

    if (!dropzone || !fileInput) return;

    dropzone.addEventListener("click", () => fileInput.click());

    dropzone.addEventListener("dragover", (e) => {
        e.preventDefault();
        dropzone.classList.add("dragover");
    });

    dropzone.addEventListener("dragleave", () => {
        dropzone.classList.remove("dragover");
    });

    dropzone.addEventListener("drop", (e) => {
        e.preventDefault();
        dropzone.classList.remove("dragover");
        if (e.dataTransfer.files.length > 0) {
            handleMiniUpload(e.dataTransfer.files[0]);
        }
    });

    fileInput.addEventListener("change", (e) => {
        if (e.target.files.length > 0) {
            handleMiniUpload(e.target.files[0]);
        }
    });

    async function handleMiniUpload(file) {
        if (!file.name.toLowerCase().endsWith(".pdf")) {
            window.showToast("Please upload a PDF document.", "warning");
            return;
        }

        statusBox.classList.remove("d-none");
        statusText.textContent = `Processing & indexing "${file.name}"...`;

        const formData = new FormData();
        formData.append("file", file);

        try {
            const res = await fetch("/api/upload", {
                method: "POST",
                body: formData
            });
            const data = await res.json();

            if (data.success) {
                window.showToast(`"${data.filename}" indexed (${data.chunks} chunks)!`, "success");
                loadDashboardStats();
            } else {
                window.showToast(data.error || "Upload failed", "danger");
            }
        } catch (err) {
            window.showToast(`Upload error: ${err.message}`, "danger");
        } finally {
            statusBox.classList.add("d-none");
            fileInput.value = "";
        }
    }
}
