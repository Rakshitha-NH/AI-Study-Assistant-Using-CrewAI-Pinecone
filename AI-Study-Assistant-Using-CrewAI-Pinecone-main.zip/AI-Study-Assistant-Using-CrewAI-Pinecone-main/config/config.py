"""
Central configuration management for the AI Study Assistant.
Loads environment variables safely and defines system-wide constants.
"""
import os
from pathlib import Path
from dotenv import load_dotenv

# Base project directory
BASE_DIR = Path(__file__).resolve().parent.parent

# Load environment variables from .env if present
ENV_PATH = BASE_DIR / '.env'
load_dotenv(dotenv_path=ENV_PATH)


class Config:
    """Application configuration class."""

    # App Details
    APP_NAME = "AI Study Assistant Using CrewAI & Pinecone"
    APP_VERSION = "1.0.0"
    BASE_DIR = BASE_DIR

    # Flask Settings
    SECRET_KEY = os.getenv("SECRET_KEY", "ai-study-assistant-secure-college-key-2025")
    FLASK_PORT = int(os.getenv("FLASK_PORT", 5000))
    FLASK_DEBUG = os.getenv("FLASK_DEBUG", "False").lower() in ("true", "1", "t")

    # Storage Paths
    UPLOAD_FOLDER = os.path.join(BASE_DIR, "uploads")
    DATA_FOLDER = os.path.join(BASE_DIR, "data")
    DOC_STORE_PATH = os.path.join(DATA_FOLDER, "doc_store.json")
    ALLOWED_EXTENSIONS = {"pdf"}
    MAX_CONTENT_LENGTH = 32 * 1024 * 1024  # 32 MB max upload limit

    # Groq API Configuration
    GROQ_API_KEY = os.getenv("GROQ_API_KEY", "").strip()
    GROQ_MODEL = os.getenv("GROQ_MODEL", "openai/gpt-oss-120b").strip()

    # Pinecone Vector Database Configuration
    PINECONE_API_KEY = os.getenv("PINECONE_API_KEY", "").strip()
    PINECONE_INDEX_NAME = os.getenv("PINECONE_INDEX_NAME", "ai-study-assistant").strip()
    PINECONE_ENVIRONMENT = os.getenv("PINECONE_ENVIRONMENT", "us-east-1").strip()
    PINECONE_CLOUD = os.getenv("PINECONE_CLOUD", "aws").strip()

    # Embedding Configuration (sentence-transformers/all-MiniLM-L6-v2 produces 384-dim vectors)
    EMBEDDING_MODEL_NAME = os.getenv("EMBEDDING_MODEL", "sentence-transformers/all-MiniLM-L6-v2").strip()
    EMBEDDING_DIMENSION = 384

    # RAG Text Chunking & Retrieval Parameters
    CHUNK_SIZE = int(os.getenv("CHUNK_SIZE", 800))
    CHUNK_OVERLAP = int(os.getenv("CHUNK_OVERLAP", 100))
    TOP_K = int(os.getenv("TOP_K", 5))

    @classmethod
    def is_groq_configured(cls) -> bool:
        """Check if a valid Groq API key is configured."""
        return bool(cls.GROQ_API_KEY and cls.GROQ_API_KEY != "your_groq_api_key_here")

    @classmethod
    def is_pinecone_configured(cls) -> bool:
        """Check if a valid Pinecone API key is configured."""
        return bool(cls.PINECONE_API_KEY and cls.PINECONE_API_KEY != "your_pinecone_api_key_here")

    @classmethod
    def get_system_status(cls) -> dict:
        """Return a summary dictionary of system configuration health."""
        return {
            "app_name": cls.APP_NAME,
            "version": cls.APP_VERSION,
            "groq_configured": cls.is_groq_configured(),
            "groq_model": cls.GROQ_MODEL,
            "pinecone_configured": cls.is_pinecone_configured(),
            "pinecone_index": cls.PINECONE_INDEX_NAME,
            "embedding_model": cls.EMBEDDING_MODEL_NAME,
            "embedding_dim": cls.EMBEDDING_DIMENSION,
            "chunk_size": cls.CHUNK_SIZE,
            "chunk_overlap": cls.CHUNK_OVERLAP,
            "top_k": cls.TOP_K,
        }


# Ensure directories exist
os.makedirs(Config.UPLOAD_FOLDER, exist_ok=True)
os.makedirs(Config.DATA_FOLDER, exist_ok=True)
