"""Configuration package for AI Study Assistant."""
from config.config import Config

__all__ = ["Config"]
