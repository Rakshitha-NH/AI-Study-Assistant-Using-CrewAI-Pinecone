"""
Pinecone Vector Database Manager.
Handles index lifecycle, batch vector upserts with rich metadata, and semantic similarity search.
"""
import time
from typing import List, Dict, Any
from config.config import Config
from rag.embeddings import EmbeddingManager


class PineconeManager:
    """Manages all Pinecone interactions."""
    _client = None
    _index = None

    @classmethod
    def get_client(cls):
        """Get or initialize Pinecone client."""
        if not Config.is_pinecone_configured():
            raise ValueError("Pinecone API key is not configured. Please add PINECONE_API_KEY to your .env file.")

        if cls._client is None:
            from pinecone import Pinecone
            cls._client = Pinecone(api_key=Config.PINECONE_API_KEY)
        return cls._client

    @classmethod
    def ensure_index_exists(cls) -> Any:
        """Ensure the target Pinecone index is created and ready."""
        pc = cls.get_client()
        index_name = Config.PINECONE_INDEX_NAME

        existing_indexes = [idx.name for idx in pc.list_indexes()]

        if index_name not in existing_indexes:
            from pinecone import ServerlessSpec
            try:
                pc.create_index(
                    name=index_name,
                    dimension=Config.EMBEDDING_DIMENSION,
                    metric="cosine",
                    spec=ServerlessSpec(
                        cloud=Config.PINECONE_CLOUD,
                        region=Config.PINECONE_ENVIRONMENT
                    )
                )
                # Wait until index is ready
                while not pc.describe_index(index_name).status["ready"]:
                    time.sleep(1)
            except Exception as e:
                # If already created in race condition, ignore
                if "already exists" not in str(e).lower():
                    raise RuntimeError(f"Failed to create Pinecone index '{index_name}': {str(e)}")

        cls._index = pc.Index(index_name)
        return cls._index

    @classmethod
    def get_index(cls):
        """Get index reference, ensuring it exists."""
        if cls._index is None:
            cls.ensure_index_exists()
        return cls._index

    @classmethod
    def upsert_chunks(cls, chunks: List[Dict], batch_size: int = 50) -> int:
        """
        Embed and upsert chunk records into Pinecone.
        
        Each vector is stored with:
        - id: chunk_id
        - values: embedding vector (384-dim)
        - metadata: { filename, page, text, doc_id }
        """
        if not chunks:
            return 0

        index = cls.get_index()
        texts = [c["text"] for c in chunks]
        embeddings = EmbeddingManager.generate_embeddings(texts)

        vectors_to_upsert = []
        for chunk, embedding in zip(chunks, embeddings):
            vectors_to_upsert.append({
                "id": chunk["id"],
                "values": embedding,
                "metadata": {
                    "doc_id": chunk["doc_id"],
                    "filename": chunk["filename"],
                    "page": int(chunk["page"]),
                    "text": chunk["text"]
                }
            })

        total_upserted = 0
        for i in range(0, len(vectors_to_upsert), batch_size):
            batch = vectors_to_upsert[i : i + batch_size]
            index.upsert(vectors=batch)
            total_upserted += len(batch)

        return total_upserted

    @classmethod
    def search(cls, query: str, top_k: int = None) -> List[Dict]:
        """
        Perform semantic search against Pinecone index.
        
        Returns:
            List of matching chunks with similarity score and metadata.
        """
        top_k = top_k or Config.TOP_K
        index = cls.get_index()

        query_vector = EmbeddingManager.generate_embedding(query)
        response = index.query(
            vector=query_vector,
            top_k=top_k,
            include_metadata=True
        )

        results = []
        for match in response.get("matches", []):
            metadata = match.get("metadata", {})
            results.append({
                "id": match.get("id"),
                "score": float(match.get("score", 0.0)),
                "text": metadata.get("text", ""),
                "filename": metadata.get("filename", "Unknown Document"),
                "page": int(metadata.get("page", 1)),
                "doc_id": metadata.get("doc_id", "")
            })

        return results

    @classmethod
    def delete_document_vectors(cls, doc_id: str) -> bool:
        """Delete all vector embeddings belonging to a specific document."""
        try:
            index = cls.get_index()
            # Delete by metadata filter if supported
            index.delete(filter={"doc_id": {"$eq": doc_id}})
            return True
        except Exception:
            # Fallback or silent if filter delete isn't enabled
            return False

    @classmethod
    def get_index_stats(cls) -> Dict[str, Any]:
        """Fetch real-time stats from Pinecone index."""
        try:
            if not Config.is_pinecone_configured():
                return {"status": "Not Configured", "vector_count": 0}
            index = cls.get_index()
            stats = index.describe_index_stats()
            return {
                "status": "Connected",
                "vector_count": stats.get("total_vector_count", 0),
                "dimension": stats.get("dimension", Config.EMBEDDING_DIMENSION)
            }
        except Exception as e:
            return {"status": f"Error: {str(e)}", "vector_count": 0}
