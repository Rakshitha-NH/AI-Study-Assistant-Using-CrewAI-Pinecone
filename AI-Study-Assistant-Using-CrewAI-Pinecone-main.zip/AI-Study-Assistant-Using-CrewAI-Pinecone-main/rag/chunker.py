"""
Text Chunker Module.
Splits extracted document page texts into meaningful, overlapping chunks with accurate metadata.
"""
from typing import List, Dict
from config.config import Config


class TextChunker:
    """Splits document text into overlapping chunks while preserving page provenance."""

    @classmethod
    def split_text_into_chunks(
        cls,
        text: str,
        chunk_size: int = None,
        chunk_overlap: int = None
    ) -> List[str]:
        """
        Split a block of text into semantic chunks using paragraph and sentence boundaries.
        """
        chunk_size = chunk_size or Config.CHUNK_SIZE
        chunk_overlap = chunk_overlap or Config.CHUNK_OVERLAP

        if not text:
            return []

        if len(text) <= chunk_size:
            return [text]

        chunks = []
        start = 0
        text_len = len(text)

        while start < text_len:
            end = min(start + chunk_size, text_len)
            
            # If not at the very end of the text, try to find a natural break point
            if end < text_len:
                # Look for paragraph break
                para_break = text.rfind('\n\n', start, end)
                if para_break != -1 and para_break > start + chunk_size // 2:
                    end = para_break + 2
                else:
                    # Look for sentence break
                    sentence_break = max(
                        text.rfind('. ', start, end),
                        text.rfind('? ', start, end),
                        text.rfind('! ', start, end),
                        text.rfind('; ', start, end)
                    )
                    if sentence_break != -1 and sentence_break > start + chunk_size // 2:
                        end = sentence_break + 2
                    else:
                        # Fallback to word boundary
                        space_break = text.rfind(' ', start, end)
                        if space_break != -1 and space_break > start + chunk_size // 3:
                            end = space_break + 1

            chunk = text[start:end].strip()
            if chunk:
                chunks.append(chunk)

            # Move forward taking overlap into account
            if end >= text_len:
                break
            start = max(start + 1, end - chunk_overlap)

        return chunks

    @classmethod
    def chunk_document(
        cls,
        pages_data: List[Dict],
        filename: str,
        doc_id: str,
        chunk_size: int = None,
        chunk_overlap: int = None
    ) -> List[Dict]:
        """
        Process extracted page texts into structured chunks.
        
        Returns:
            List of dicts: [
                {
                    "id": "doc_123_p1_c0",
                    "doc_id": "doc_123",
                    "filename": "lecture1.pdf",
                    "page": 1,
                    "chunk_index": 0,
                    "text": "...",
                    "char_count": 780
                },
                ...
            ]
        """
        chunk_size = chunk_size or Config.CHUNK_SIZE
        chunk_overlap = chunk_overlap or Config.CHUNK_OVERLAP
        all_chunks = []
        global_chunk_idx = 0

        for page_info in pages_data:
            page_num = page_info["page"]
            page_text = page_info.get("text", "").strip()

            if not page_text:
                continue

            page_chunks = cls.split_text_into_chunks(page_text, chunk_size, chunk_overlap)

            for local_idx, chunk_text in enumerate(page_chunks):
                chunk_id = f"{doc_id}_p{page_num}_c{local_idx}"
                all_chunks.append({
                    "id": chunk_id,
                    "doc_id": doc_id,
                    "filename": filename,
                    "page": page_num,
                    "chunk_index": global_chunk_idx,
                    "text": chunk_text,
                    "char_count": len(chunk_text)
                })
                global_chunk_idx += 1

        return all_chunks
