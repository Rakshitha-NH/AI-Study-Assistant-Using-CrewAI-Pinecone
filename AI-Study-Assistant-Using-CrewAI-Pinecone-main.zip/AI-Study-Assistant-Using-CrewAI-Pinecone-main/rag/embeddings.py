"""
Embedding Manager Module.
Uses SentenceTransformers to generate dense vector embeddings locally (all-MiniLM-L6-v2, 384 dims).
"""
from typing import List
from config.config import Config


class EmbeddingManager:
    """Singleton embedding generator to ensure model loads once into memory."""
    _instance = None
    _model = None

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super(EmbeddingManager, cls).__new__(cls)
        return cls._instance

    @classmethod
    def get_model(cls):
        """Lazy load the sentence transformer model."""
        if cls._model is None:
            try:
                from sentence_transformers import SentenceTransformer
                cls._model = SentenceTransformer(Config.EMBEDDING_MODEL_NAME)
            except Exception as e:
                raise RuntimeError(
                    f"Failed to load embedding model '{Config.EMBEDDING_MODEL_NAME}'. "
                    f"Ensure 'sentence-transformers' is installed: {str(e)}"
                )
        return cls._model

    @classmethod
    def generate_embedding(cls, text: str) -> List[float]:
        """Generate a single 384-dimensional embedding vector for a given text."""
        model = cls.get_model()
        cleaned = text.replace('\n', ' ').strip()
        vector = model.encode(cleaned, convert_to_numpy=True, normalize_embeddings=True)
        return vector.tolist()

    @classmethod
    def generate_embeddings(cls, texts: List[str]) -> List[List[float]]:
        """Batch generate embeddings for multiple texts."""
        if not texts:
            return []
        model = cls.get_model()
        cleaned_texts = [t.replace('\n', ' ').strip() for t in texts]
        vectors = model.encode(cleaned_texts, batch_size=32, convert_to_numpy=True, normalize_embeddings=True)
        return [v.tolist() for v in vectors]
