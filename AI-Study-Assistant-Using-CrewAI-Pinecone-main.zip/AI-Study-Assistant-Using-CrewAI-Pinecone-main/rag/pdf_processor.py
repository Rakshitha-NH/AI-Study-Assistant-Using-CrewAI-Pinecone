"""
PDF Processor Module.
Extracts text, metadata, and page-level information from uploaded PDF files using pypdf.
"""
import os
import re
from pypdf import PdfReader


class PDFProcessor:
    """Handles PDF validation, metadata extraction, and text parsing."""

    @staticmethod
    def clean_text(text: str) -> str:
        """Clean extracted raw text by removing strange whitespace and non-printable chars."""
        if not text:
            return ""
        # Replace multiple newlines or tabs with standard spacing
        text = re.sub(r'\r\n', '\n', text)
        text = re.sub(r'\r', '\n', text)
        text = re.sub(r'[ \t]+', ' ', text)
        text = re.sub(r'\n{3,}', '\n\n', text)
        # Strip unprintable ascii control chars while preserving newlines
        text = "".join(ch for ch in text if ch == '\n' or ch == '\t' or ch >= ' ')
        return text.strip()

    @classmethod
    def extract_text_by_pages(cls, pdf_path: str) -> list[dict]:
        """
        Extract text from each page of the PDF file.
        
        Returns:
            List of dicts: [
                {"page": 1, "text": "...", "char_count": 120},
                ...
            ]
        """
        if not os.path.exists(pdf_path):
            raise FileNotFoundError(f"PDF file not found at: {pdf_path}")

        try:
            reader = PdfReader(pdf_path)
        except Exception as e:
            raise ValueError(f"Failed to read PDF file. File might be corrupted or encrypted: {str(e)}")

        total_pages = len(reader.pages)
        if total_pages == 0:
            raise ValueError("The uploaded PDF has 0 pages.")

        pages_data = []
        total_extracted_chars = 0

        for idx, page in enumerate(reader.pages):
            page_num = idx + 1
            try:
                raw_text = page.extract_text() or ""
                cleaned = cls.clean_text(raw_text)
                char_count = len(cleaned)
                total_extracted_chars += char_count

                pages_data.append({
                    "page": page_num,
                    "text": cleaned,
                    "char_count": char_count
                })
            except Exception as e:
                # Still record page with empty text if extraction fails on single page
                pages_data.append({
                    "page": page_num,
                    "text": "",
                    "char_count": 0,
                    "error": str(e)
                })

        if total_extracted_chars == 0:
            raise ValueError(
                "No readable text could be extracted from this PDF. "
                "It may contain scanned images or be protected."
            )

        return pages_data

    @classmethod
    def get_pdf_metadata(cls, pdf_path: str) -> dict:
        """Extract basic document metadata (page count, title, file size)."""
        if not os.path.exists(pdf_path):
            return {}

        file_size_bytes = os.path.getsize(pdf_path)
        size_formatted = f"{file_size_bytes / (1024 * 1024):.2f} MB" if file_size_bytes >= 1024*1024 else f"{file_size_bytes / 1024:.1f} KB"

        try:
            reader = PdfReader(pdf_path)
            num_pages = len(reader.pages)
            info = reader.metadata or {}
            title = info.title or os.path.basename(pdf_path)
        except Exception:
            num_pages = 0
            title = os.path.basename(pdf_path)

        return {
            "filename": os.path.basename(pdf_path),
            "file_size": size_formatted,
            "file_size_bytes": file_size_bytes,
            "page_count": num_pages,
            "title": title
        }
