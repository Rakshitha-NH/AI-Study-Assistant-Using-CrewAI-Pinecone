"""Crew management and coordination package."""
from crew.tasks import create_research_task, create_analysis_task, create_review_task
from crew.crew_manager import CrewManager

__all__ = ["create_research_task", "create_analysis_task", "create_review_task", "CrewManager"]
