"""
Crew Manager Module.
Coordinates LLM setup, Agent instantiation, Task scheduling, and sequential multi-agent execution:
Research Agent (Researcher) -> Analysis Agent (Analyst) -> Review Agent (Reviewer).
"""
import os
from typing import List, Dict, Any
from config.config import Config
from agents.research_agent import create_research_agent
from agents.analysis_agent import create_analysis_agent
from agents.review_agent import create_review_agent
from crew.tasks import create_research_task, create_analysis_task, create_review_task


class CrewManager:
    """Orchestrates CrewAI Multi-Agent execution."""

    @classmethod
    def format_chunks_for_context(cls, chunks: List[Dict]) -> str:
        """Format retrieved Pinecone chunks into readable context for agents."""
        if not chunks:
            return "No relevant study material chunks were retrieved."

        formatted_passages = []
        for idx, chunk in enumerate(chunks, 1):
            filename = chunk.get("filename", "Unknown Document")
            page = chunk.get("page", 1)
            text = chunk.get("text", "").strip()
            score = chunk.get("score", 0.0)

            formatted_passages.append(
                f"--- [Passage {idx} | Document: {filename} | Page: {page} | Relevance Score: {score:.3f}] ---\n{text}"
            )

        return "\n\n".join(formatted_passages)

    @classmethod
    def extract_sources(cls, chunks: List[Dict]) -> List[Dict[str, Any]]:
        """Extract deduplicated source citations from retrieved chunks."""
        seen = set()
        sources = []
        for chunk in chunks:
            filename = chunk.get("filename", "Unknown Document")
            page = int(chunk.get("page", 1))
            key = (filename, page)
            if key not in seen:
                seen.add(key)
                sources.append({
                    "filename": filename,
                    "page": page,
                    "score": round(chunk.get("score", 0.0), 3)
                })
        return sources

    @classmethod
    def run_multi_agent_pipeline_groq(cls, question: str, context_str: str) -> str:
        """
        Executes sequential 3-Agent reasoning pipeline using Groq LLM:
        1. Research Agent: Extract facts and source references.
        2. Analysis Agent: Draft comprehensive student-friendly explanation.
        3. Review Agent: Audit claims against source text to eliminate hallucinations.
        """
        try:
            from groq import Groq
            client = Groq(api_key=Config.GROQ_API_KEY)
            model_name = Config.GROQ_MODEL
        except Exception as e:
            raise RuntimeError(f"Failed to initialize Groq client: {str(e)}")

        # Step 1: Research Agent
        research_prompt = (
            f"You are the 'Study Material Researcher' agent.\n"
            f"Your Goal: Extract all relevant factual evidence, definitions, formulas, and notes from the retrieved study material.\n\n"
            f"STUDENT QUESTION:\n\"{question}\"\n\n"
            f"RETRIEVED STUDY MATERIAL PASSAGES:\n{context_str}\n\n"
            f"Extract ONLY facts supported by the text above. Cite source document names and page numbers."
        )
        research_resp = client.chat.completions.create(
            model=model_name,
            messages=[{"role": "user", "content": research_prompt}],
            temperature=0.1
        )
        research_output = research_resp.choices[0].message.content

        # Step 2: Analysis Agent
        analysis_prompt = (
            f"You are the 'Study Material Analyst' agent.\n"
            f"Your Goal: Synthesize a clear, structured, and student-friendly explanation answering the question.\n\n"
            f"STUDENT QUESTION:\n\"{question}\"\n\n"
            f"RESEARCHER FINDINGS:\n{research_output}\n\n"
            f"ORIGINAL CONTEXT:\n{context_str}\n\n"
            f"INSTRUCTIONS:\n"
            f"1. Explain concepts simply with clear headings and bullet points.\n"
            f"2. If the material does not contain the answer, say:\n"
            f"   \"I could not find enough information in the uploaded study material to answer this question.\"\n"
            f"3. Do not invent any outside knowledge."
        )
        analysis_resp = client.chat.completions.create(
            model=model_name,
            messages=[{"role": "user", "content": analysis_prompt}],
            temperature=0.2
        )
        analysis_output = analysis_resp.choices[0].message.content

        # Step 3: Review Agent
        review_prompt = (
            f"You are the 'Answer Reviewer' agent.\n"
            f"Your Goal: Audit the draft answer against the raw study material excerpts. Eliminate any hallucinations or ungrounded claims.\n\n"
            f"STUDENT QUESTION:\n\"{question}\"\n\n"
            f"DRAFT ANSWER FROM ANALYST:\n{analysis_output}\n\n"
            f"RAW STUDY MATERIAL EXCERPTS:\n{context_str}\n\n"
            f"INSTRUCTIONS:\n"
            f"1. Check that every statement is directly supported by the excerpts.\n"
            f"2. Remove any unsupported sentences.\n"
            f"3. Polish Markdown formatting (bold keywords, clean lists).\n"
            f"4. Return ONLY the verified final answer."
        )
        review_resp = client.chat.completions.create(
            model=model_name,
            messages=[{"role": "user", "content": review_prompt}],
            temperature=0.1
        )
        final_answer = review_resp.choices[0].message.content
        return final_answer

    @classmethod
    def run_study_assistant(cls, question: str, retrieved_chunks: List[Dict]) -> Dict[str, Any]:
        """
        Execute the full 3-Agent workflow sequentially:
        Research Agent -> Analysis Agent -> Review Agent
        """
        if not retrieved_chunks:
            return {
                "success": True,
                "question": question,
                "answer": (
                    "I could not find any relevant information in your uploaded study materials "
                    "to answer this question. Please make sure you have uploaded relevant PDF documents."
                ),
                "sources": [],
                "chunks_used": 0
            }

        context_str = cls.format_chunks_for_context(retrieved_chunks)
        sources = cls.extract_sources(retrieved_chunks)

        if not Config.is_groq_configured():
            return {
                "success": False,
                "error": "Groq API key is not configured. Please add GROQ_API_KEY to your .env file."
            }

        # Attempt CrewAI native orchestration first, fallback to direct Groq multi-agent flow
        try:
            from crewai import Crew, Process, Agent, Task
            from langchain_groq import ChatGroq

            llm = ChatGroq(
                groq_api_key=Config.GROQ_API_KEY,
                model_name=Config.GROQ_MODEL,
                temperature=0.2
            )
            research_agent = create_research_agent(llm)
            analysis_agent = create_analysis_agent(llm)
            review_agent = create_review_agent(llm)

            task1 = create_research_task(research_agent, question, context_str)
            task2 = create_analysis_task(analysis_agent, question, task1, context_str)
            task3 = create_review_task(review_agent, question, task2, context_str)

            crew = Crew(
                agents=[research_agent, analysis_agent, review_agent],
                tasks=[task1, task2, task3],
                process=Process.sequential,
                verbose=True
            )
            crew_result = crew.kickoff()
            answer_text = str(crew_result).strip()
        except Exception:
            # Direct multi-agent Groq execution
            answer_text = cls.run_multi_agent_pipeline_groq(question, context_str)

        return {
            "success": True,
            "question": question,
            "answer": answer_text,
            "sources": sources,
            "chunks_used": len(retrieved_chunks)
        }
