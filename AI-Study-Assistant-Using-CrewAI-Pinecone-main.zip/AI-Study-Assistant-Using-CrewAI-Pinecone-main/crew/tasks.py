"""
CrewAI Task definitions for sequential multi-agent processing.
Task 1: Research retrieved context -> Task 2: Analyze & Draft -> Task 3: Fact-Check & Finalize
"""
def create_research_task(agent, question: str, retrieved_context: str):
    """Task 1: Extract relevant facts from retrieved document chunks."""
    try:
        from crewai import Task
    except ImportError:
        raise ImportError("CrewAI is required to run tasks. Please run 'pip install crewai'.")

    return Task(
        description=(
            f"Analyze the following retrieved study material passages and extract all relevant "
            f"facts, definitions, equations, and explanations related to the student's question.\n\n"
            f"STUDENT QUESTION:\n\"{question}\"\n\n"
            f"RETRIEVED STUDY MATERIAL PASSAGES:\n"
            f"{retrieved_context}\n\n"
            f"INSTRUCTIONS:\n"
            f"1. Extract ONLY facts present in the text above.\n"
            f"2. Note the source document and page number for each finding.\n"
            f"3. If the material does not cover the question, state that clearly."
        ),
        expected_output=(
            "A structured bulleted list of factual evidence and notes extracted from the study material, "
            "including source references (Document and Page numbers)."
        ),
        agent=agent
    )


def create_analysis_task(agent, question: str, research_task, retrieved_context: str):
    """Task 2: Synthesize research findings into a student-friendly explanation."""
    try:
        from crewai import Task
    except ImportError:
        raise ImportError("CrewAI is required to run tasks. Please run 'pip install crewai'.")

    return Task(
        description=(
            f"Using the findings from the Study Material Researcher and the original study material, "
            f"compose a clear, educational, and well-structured answer to the student's question.\n\n"
            f"STUDENT QUESTION:\n\"{question}\"\n\n"
            f"ORIGINAL CONTEXT:\n"
            f"{retrieved_context}\n\n"
            f"INSTRUCTIONS:\n"
            f"1. Write in a student-friendly, pedagogical tone.\n"
            f"2. Use headings, bullet points, and numbered lists to make the answer easy to learn.\n"
            f"3. If the study material lacks enough information to answer the question, output EXACTLY:\n"
            f"   \"I could not find enough information in the uploaded study material to answer this question.\"\n"
            f"4. Do not invent any outside knowledge."
        ),
        expected_output=(
            "A draft comprehensive educational answer to the student's question based strictly on the uploaded material."
        ),
        agent=agent,
        context=[research_task]
    )


def create_review_task(agent, question: str, analysis_task, retrieved_context: str):
    """Task 3: Fact-check the draft against original excerpts and finalize formatting."""
    try:
        from crewai import Task
    except ImportError:
        raise ImportError("CrewAI is required to run tasks. Please run 'pip install crewai'.")

    return Task(
        description=(
            f"Cross-check the draft answer against the raw retrieved study material excerpts.\n\n"
            f"STUDENT QUESTION:\n\"{question}\"\n\n"
            f"ORIGINAL STUDY MATERIAL EXCERPTS:\n"
            f"{retrieved_context}\n\n"
            f"INSTRUCTIONS:\n"
            f"1. Verify that every single claim in the draft is directly supported by the study material excerpts.\n"
            f"2. Remove or correct any hallucinated or unsupported statements.\n"
            f"3. Polish the Markdown formatting for maximum readability (bold key terms, clean lists).\n"
            f"4. If the draft indicates insufficient information, keep that honest response.\n"
            f"5. Output ONLY the final polished answer."
        ),
        expected_output=(
            "The final, fact-checked, reliable answer in clean Markdown, ready to be presented to the student."
        ),
        agent=agent,
        context=[analysis_task]
    )
